Записать, что такое `DBSet` - 50 минута урока

Код с урока
[https://github.com/AliceBit2020/RelationDB_EFCore.git](https://github.com/AliceBit2020/RelationDB_EFCore.git "https://github.com/alicebit2020/relationdb_efcore.git")

Ещё код с урока
Про LINQ-запросы
[LINQ_ToEntities/LINQ_ToEntities/Program.cs at master · AliceBit2020/LINQ_ToEntities](https://github.com/AliceBit2020/LINQ_ToEntities/blob/master/LINQ_ToEntities/Program.cs)

